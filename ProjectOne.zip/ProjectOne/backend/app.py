from flask import Flask, request
import hashlib
from dotenv import load_dotenv
import os
import pymongo
load_dotenv()
DB_LINK = os.getenv('DB_LINK')
client = pymongo.MongoClient(DB_LINK)
db = client.susanta
userCollection = db['users']
app = Flask(__name__)
@app.route('/')
def home():
    return "Hello World"
@app.route('/save', methods=['POST'])
def save():
    data = dict(request.json)
    user = userCollection.find_one({"email": data['email']})
    if(user):
        data['password'] = hashlib.md5(data['password'].encode()).hexdigest()
        result = userCollection.userCollection.update_one(
            {"email": data['email']},
            {"$set": data}
        )
        data['_id'] = str(user['_id'])
    else:
        data['password'] = hashlib.md5(data['password'].encode()).hexdigest()
        result = userCollection.insert_one(data)
        data['_id'] = str(result.inserted_id)
    return data
@app.route('/view')
def view():
    users = list(userCollection.find())
    # convert ObjectId to string
    for user in users:
        user['_id'] = str(user['_id'])
    return users
if __name__ == "__main__":
    app.run(port=3001,host='0.0.0.0',debug=True)