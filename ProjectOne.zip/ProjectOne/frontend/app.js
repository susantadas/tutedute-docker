const express = require('express');
const path = require('path');
require('dotenv').config();
let app = express();
app.set('view engine', 'ejs');
const URL = process.env.BASE_URL || 'http://localhost:3001';
// dynamic import for node-fetch
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
app.use(express.static(path.join(__dirname, 'src')));
app.get('/', async function (req, res) {
    const option = { method: "GET" };
    try {
        let response = await fetch(URL + '/view', option);
        let data = await response.json();
        res.render('index', { data: data });
    } catch (e) {
        console.log(e)
        res.render('error', { data: e });
    }
});
app.listen(3000, function () {
    console.log("port number is: 3000");
});